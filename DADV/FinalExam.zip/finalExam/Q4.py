#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  2 12:00:59 2021

@author: tsheringlhamo
"""
import pandas as pd
import matplotlib.pyplot as plt

sp500 = pd.read_csv("/Users/tsheringlhamo/Specialisation/DADV/finalExam/SP500.csv", sep = ',')
sp500.set_index('Symbol', inplace = True)

topSectors = {}
bottomSectors = {}
topCount = {}
bottomCount = {}

def findSectors(file, dict):
    for line in file:
        line = line.strip("\n")
        dict[line] = sp500.loc[line].iloc[2] #key=symbol, value = sector
    return

def countSectors(sectorDict, countDict):
    for each in sectorDict.keys():
        sector = sectorDict.get(each)
        if sector in countDict.keys():
            countDict[sector] += 1
        else:
            countDict[sector] = 1
    return

with open("/Users/tsheringlhamo/Specialisation/DADV/finalExam/Daily/top.txt", 'r+') as f:
    lines = f.readlines()

findSectors(lines, topSectors)   
#print(topDict)

with open("/Users/tsheringlhamo/Specialisation/DADV/finalExam/Daily/bottom.txt", 'r+') as f:
    lines = f.readlines()

findSectors(lines, bottomSectors)
countSectors(topSectors, topCount)
countSectors(bottomSectors, bottomCount)

#plot graph
width = 0.25
bar1 = plt.bar(topCount.keys(), topCount.values(), -width, align='edge', color = 'blue', label = 'top')
bar2 = plt.bar(bottomCount.keys(), bottomCount.values(), +width, align='edge', color= 'r', label = 'bottom')

plt.xlabel('Sectors')
plt.ylabel('Count')
plt.title('sector count in top and bottom')
plt.legend()
plt.show()


