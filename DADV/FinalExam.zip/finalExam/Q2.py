#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  2 09:58:01 2021

@author: tsheringlhamo
"""

import glob
import os
import pandas as pd

def gainORloss(files, outdir):
    for file in glob.glob(files):
        f = open(file, 'r')
        name = os.path.basename(f.name).replace(".csv","")
        data_df = pd.read_csv(f)
        #print(data_df)
        lis = []
        for each in range(0, len(data_df)-1):
            row1 = data_df.iloc[each]
            row2 = data_df.iloc[each+1]
            gainloss = ((row2["Close"] - row1['Close'])*100) 
            lis.append(gainloss)
        #print(lis)
        lis.insert(0,0)
        data_df.loc[:,'gainORloss'] = lis
        data_df.to_csv(outdir+name+'.GL.csv')
        f.close()
    #print(lis)

#daily
gainORloss('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Daily/*.csv', '/Users/tsheringlhamo/Specialisation/DADV/finalExam/Daily/gainLoss/')
#weekly
gainORloss('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Weekly/*.csv', '/Users/tsheringlhamo/Specialisation/DADV/finalExam/Weekly/gainLoss/')
#maonthly
gainORloss('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Monthly/*.csv', '/Users/tsheringlhamo/Specialisation/DADV/finalExam/Monthly/gainLoss/')
print("Gain/loss calculation finished")
