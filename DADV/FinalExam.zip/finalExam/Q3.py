#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  2 10:14:34 2021

@author: tsheringlhamo
"""

import glob
import os
import pandas as pd
import seaborn as sn
import matplotlib.pyplot as plt


def findGainers(files):
    df = pd.DataFrame()
    for file in glob.glob(files):
        f=open(file, 'r')
        name = os.path.basename(f.name).replace(".GL.csv","")
        data = pd.read_csv(f)
        gainLoss = data[["gainORloss"]].sort_values('gainORloss') #in ascending order
        bottom = gainLoss['gainORloss'].values[1] #first row is always zero
        top = gainLoss['gainORloss'].values[len(gainLoss)-1]
        df = df.append({'symbol': name, 'top': top, 'bottom': bottom}, ignore_index = True)
    return df
    
def plotMatrix(df, outdir):
    #print(df)
    top = df[['symbol', 'top']].sort_values('top', ascending = False).iloc[0:12, :]
    #print(top)
    bottom= df[['symbol', 'bottom']].sort_values('bottom').iloc[0:12, :]
    #print(bottom12)
    
    with open(outdir+'top.txt', 'w+') as f:   
        f.write("\n".join(top['symbol']))
    
    with open(outdir+'bottom.txt', 'w+') as f:   
        f.write("\n".join(bottom['symbol']))
    
    top.set_index('symbol', inplace = True)
    bottom.set_index('symbol', inplace = True)
    
    corrMatrix1 = top.T.corr()
    #plt.matshow(corrMatrix1)
    sn.heatmap(corrMatrix1, annot = True, cmap = 'RdBu')
    plt.title("Correlation matrix for top gainers")
    plt.show()
    corrMatrix2 = bottom.T.corr()
    sn.heatmap(corrMatrix2, annot = True, cmap = 'RdBu')
    plt.title("Correlation matrix for bottom gainers")
    #plt.show()

#daily
df1 = findGainers('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Daily/gainLoss/*.csv')
#weekly
df2 = findGainers('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Weekly/gainLoss/*.csv')
#monthly
df3 = findGainers('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Monthly/gainLoss/*.csv')

#plot corelation matrix
plotMatrix(df1, '/Users/tsheringlhamo/Specialisation/DADV/finalExam/Daily/')

plotMatrix(df2, '/Users/tsheringlhamo/Specialisation/DADV/finalExam/Weekly/')
plotMatrix(df3, '/Users/tsheringlhamo/Specialisation/DADV/finalExam/Monthly/')


    
