#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  2 09:58:01 2021

@author: tsheringlhamo
"""

import glob
import os
import pandas as pd

#daily
for files in glob.glob('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Daily/*.csv'):
    f = open(files, 'r')
    name = os.path.basename(f.name).replace(".csv","")
    data_df = pd.read_csv(f)
    #print(data_df)
    lis = []
    for each in range(0, len(data_df)-1):
        row1 = data_df.iloc[each]
        row2 = data_df.iloc[each+1]
        gainloss = ((row2["Close"] - row1['Close'])*100) 
        lis.append(gainloss)
    #print(lis)
    lis.insert(0,0)
    data_df.loc[:,'gainORloss'] = lis
    data_df.to_csv(r'/Users/tsheringlhamo/Specialisation/DADV/finalExam/Daily/gainLoss/'+name+'.GL.csv')
    f.close()
#print(lis)

#weekly
for files in glob.glob('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Weekly/*.csv'):
    f = open(files, 'r')
    name = os.path.basename(f.name).replace(".csv","")
    data_df = pd.read_csv(f)
    #print(data_df)
    lis = []
    for each in range(0, len(data_df)-1):
        row1 = data_df.iloc[each]
        row2 = data_df.iloc[each+1]
        gainloss = ((row2["Close"] - row1['Close'])*100) 
        lis.append(gainloss)
    #print(lis)
    lis.insert(0,0)
    data_df.loc[:,'gainORloss'] = lis
    data_df.to_csv(r'/Users/tsheringlhamo/Specialisation/DADV/finalExam/Weekly/gainLoss/'+name+'.GL.csv')
    f.close()

#monthly   
for files in glob.glob('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Monthly/*.csv'):
    f = open(files, 'r')
    name = os.path.basename(f.name).replace(".csv","")
    data_df = pd.read_csv(f)
    #print(data_df)
    lis = []
    for each in range(0, len(data_df)-1):
        row1 = data_df.iloc[each]
        row2 = data_df.iloc[each+1]
        gainloss = ((row2["Close"] - row1['Close'])*100) 
        lis.append(gainloss)
    #print(lis)
    lis.insert(0,0)
    data_df.loc[:,'gainORloss'] = lis
    data_df.to_csv(r'/Users/tsheringlhamo/Specialisation/DADV/finalExam/Monthly/gainLoss/'+name+'.GL.csv')
    f.close()