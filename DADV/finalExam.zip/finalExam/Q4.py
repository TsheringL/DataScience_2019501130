#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  2 12:27:59 2021

@author: tsheringlhamo
"""
import pandas as pd

sp500 = pd.read_csv("/Users/tsheringlhamo/Specialisation/DADV/finalExam/SP500.csv", sep = ',')
sp500.set_index('Symbol', inplace = True)

topDict = {}
bottomDict = {}
with open("/Users/tsheringlhamo/Specialisation/DADV/finalExam/top.txt", 'r+') as f:
    line = f.read().split('.')
    topDict[line[0]] = sp500.loc[line[0]].iloc[3] #third column

#print(topDict)

with open("/Users/tsheringlhamo/Specialisation/DADV/finalExam/bottom.txt", 'r+') as f:
    line = f.read().split('.')
    topDict[line[0]] = sp500.loc[line[0]].iloc[3] #third column

