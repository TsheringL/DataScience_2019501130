#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  2 10:14:34 2021

@author: tsheringlhamo
"""

import glob
import os
import pandas as pd
import seaborn as sn
import matplotlib.pyplot as plt


def plotMatrix(df):
    top = df.sort_values('top', ascending = False)
    bottom = df.sort_values('bottom')
    with open('/Users/tsheringlhamo/Specialisation/DADV/finalExam/top.txt', 'w+') as f:   
        f.write("\n".join(top['symbol']))
    with open('/Users/tsheringlhamo/Specialisation/DADV/finalExam/bottom.txt', 'w+') as f:   
        f.write("\n".join(bottom['symbol']))
    corrMatrix = df.corr()
    sn.heatmap(corrMatrix, annot = True, cmap = 'RdBu')
    plt.show()


df1 = pd.DataFrame()
for files in glob.glob('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Daily/gainLoss/*.csv'):
    f=open(files, 'r')
    name = os.path.basename(f.name).replace(".csv","")
    data = pd.read_csv(f)
    gainLoss = data[["gainORloss"]].sort_values('gainORloss')
    bottom = gainLoss['gainORloss'].values[1]
    top = gainLoss['gainORloss'].values[len(gainLoss)-1]
    df1 = df1.append({'symbol': name, 'top': top, 'bottom': bottom}, ignore_index = True)
plotMatrix(df1)

df2 = pd.DataFrame()
for files in glob.glob('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Weekly/gainLoss/*.csv'):
    f=open(files, 'r')
    name = os.path.basename(f.name).replace(".csv","")
    data = pd.read_csv(f)
    gainLoss = data[["gainORloss"]].sort_values('gainORloss')
    bottom = gainLoss['gainORloss'].values[1]
    top = gainLoss['gainORloss'].values[len(gainLoss)-1]
    df2 = df2.append({'symbol': name, 'top': top, 'bottom': bottom}, ignore_index = True)

df3 = pd.DataFrame()
for files in glob.glob('/Users/tsheringlhamo/Specialisation/DADV/finalExam/Monthly/gainLoss/*.csv'):
    f=open(files, 'r')
    name = os.path.basename(f.name).replace(".csv","")
    data = pd.read_csv(f)
    gainLoss = data[["gainORloss"]].sort_values('gainORloss')
    bottom = gainLoss['gainORloss'].values[1]
    top = gainLoss['gainORloss'].values[len(gainLoss)-1]
    df3 = df3.append({'symbol': name, 'top': top, 'bottom': bottom}, ignore_index = True)

    
