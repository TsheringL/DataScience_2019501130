#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  2 09:32:08 2021

@author: tsheringlhamo
"""



from selenium.webdriver.chrome.options import Options
import datetime
import time
from selenium import webdriver

count = int(input("Enter number of stock you want to find:"))
if count != None:

    chromeOptions = Options()
    chromeOptions.add_experimental_option("prefs", {"download.default_directory": "/Users/tsheringlhamo/Specialisation/DADV/finalExam/Daily"})
    driver = webdriver.Chrome(executable_path="/usr/local/bin/chromedriver", options = chromeOptions)
    driver.get("https://en.wikipedia.org/wiki/List_of_S%26P_500_companies")
    time.sleep(2)

    stockSymbols = []
    for i in range(6,count+1):
    	# time.sleep(2)
    	p = driver.find_element_by_xpath('//*[@id="constituents"]/tbody/tr['+str(i)+']/td[1]/a')
    	stockSymbols.append(p.text)
    print(stockSymbols)
    time.sleep(2)

    #Unix Time Conversion
    dtf = datetime.datetime(2018, 4, 7) #1000days from now. format year, month, day
    dtt = datetime.datetime(2021, 1, 2)
    dt_from = int(time.mktime(dtf.timetuple()))
    dt_to = int(time.mktime(dtt.timetuple()))
    # print(dt_from)
    # print(dt_to)

    # chromeOptions = Options()
    for each in stockSymbols:
        driver.get("https://finance.yahoo.com/quote/"+each+"/history?period1="+str(dt_from)+"&period2="+str(dt_to)+"&interval=1d&filter=history&frequency=1d")
        time.sleep(2)
        driver.find_element_by_xpath('/html/body/div[1]/div/div/div[1]/div/div[3]/div[1]/div/div[2]/div/div/section/div[1]/div[2]/span[2]/a/span').click()
    time.sleep(2)
    driver.close()

    chromeOptions = Options()
    chromeOptions.add_experimental_option("prefs", {"download.default_directory": "/Users/tsheringlhamo/Specialisation/DADV/finalExam/Weekly"})
    driver = webdriver.Chrome(executable_path="/usr/local/bin/chromedriver", options = chromeOptions)

    for each in stockSymbols:
        driver.get("https://finance.yahoo.com/quote/"+each+"/history?period1="+str(dt_from)+"&period2="+str(dt_to)+"&interval=1d&filter=history&frequency=1wk")
        time.sleep(2)
        driver.find_element_by_xpath('//*[@id="Col1-1-HistoricalDataTable-Proxy"]/section/div[1]/div[2]/span[2]/a/span').click()    
    time.sleep(3)
    driver.close()
    
    chromeOptions = Options()
    chromeOptions.add_experimental_option("prefs", {"download.default_directory": "/Users/tsheringlhamo/Specialisation/DADV/finalExam/Monthly"})
    driver = webdriver.Chrome(executable_path="/usr/local/bin/chromedriver", options = chromeOptions)

    for each in stockSymbols:
        driver.get("https://finance.yahoo.com/quote/"+each+"/history?period1="+str(dt_from)+"&period2="+str(dt_to)+"&interval=1d&filter=history&frequency=1mo")
        time.sleep(2)
        driver.find_element_by_xpath('//*[@id="Col1-1-HistoricalDataTable-Proxy"]/section/div[1]/div[2]/span[2]/a/span').click()
    time.sleep(3)
    driver.close()
    