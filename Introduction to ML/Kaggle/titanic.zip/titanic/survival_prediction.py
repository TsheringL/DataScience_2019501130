#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 30 11:13:36 2020

@author: tsheringlhamo
"""


import pandas as pd 
#import numpy as np
#import matplotlib.pyplot as plt
#from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.impute import KNNImputer
#from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
#from sklearn import svm
from sklearn.svm import SVC
from sklearn.metrics import classification_report
from sklearn.neighbors import KNeighborsClassifier

#read train and test datasets into pandas DataFrames trainx_df, trainy_df,testx_df
def readDataSets(train_path, test_path,predict_col,index_col=None):
    if index_col==None:
        trainx_df=pd.read_csv(train_path)
        trainy_df=trainx_df[predict_col]
        trainx_df.drop(predict_col,axis=1,inplace=True)
        testx_df=pd.read_csv(test_path)
    else:
        trainx_df=pd.read_csv(train_path,index_col=index_col)
        trainy_df=trainx_df[predict_col]
        trainx_df.drop(predict_col,axis=1,inplace=True)
        testx_df=pd.read_csv(test_path,index_col=index_col)
    return trainx_df,trainy_df,testx_df

# As a first step of pre-processing remove columns with null value ratio greater than provided limit
def dropFeaturesWithNullValues(trainx_df, testx_df,null_ratio=0.3):
    sample_size=len(trainx_df)
    columns_with_null_values=[[col,float(trainx_df[col].isnull().sum())/float(sample_size)] 
                              for col in trainx_df.columns if trainx_df[col].isnull().sum()]
    columns_to_drop=[x for (x,y) in columns_with_null_values if y>null_ratio]
    #print(columns_to_drop)
    trainx_df.drop(columns_to_drop,axis=1,inplace=True) #drop cabin column
    testx_df.drop(columns_to_drop,axis=1,inplace=True)
    return trainx_df,testx_df


def convertCategoricalFeatures(trainx_df, testx_df):
    categorical_columns=[col for col in trainx_df.columns 
                         if trainx_df[col].dtype==object] #name, sex, ticket, embarked
    gender = pd.get_dummies(trainx_df['Sex'],drop_first=True) #one new column male
    embark = pd.get_dummies(trainx_df['Embarked'],drop_first=True) #two new columns Q, S
    trainx_df.drop(categorical_columns,axis=1,inplace=True)
    trainx_df = pd.concat([trainx_df,gender,embark],axis=1)
    
    gender = pd.get_dummies(testx_df['Sex'],drop_first=True)
    #print(sex)
    embark = pd.get_dummies(testx_df['Embarked'],drop_first=True)
    testx_df.drop(categorical_columns,axis=1,inplace=True)
    testx_df = pd.concat([testx_df,gender,embark],axis=1)
    
    return trainx_df, testx_df
    
    
# As a second pre-processing step find all categorical columns and one hot  encode them. 
#Before one hot encode fill all null values with dummy in those columns.  Some categorical columns in 
#trainx_df may not have null values in but may have null values in testx_df. To overcome this 
#problem we will add a row to the trainx_df with all dummy values for categorical values. Once one
# hot encoding is complete drop the added dummy column


# As a third step of pre-processing fill all missing values for ordinal features
def fillMissingValues(trainx_df,testx_df):
    imputer = KNNImputer(n_neighbors=2)
    imputer.fit(trainx_df)
    trainx_df_filled = imputer.transform(trainx_df)
    trainx_df_filled=pd.DataFrame(trainx_df_filled,columns=trainx_df.columns)
    testx_df_filled = imputer.transform(testx_df)
    testx_df_filled=pd.DataFrame(testx_df_filled,columns=testx_df.columns)
    testx_df_filled.reset_index(drop=True,inplace=True)
    return trainx_df_filled,testx_df_filled


# As a fourth step of pre-processing scale all the features either through Standard scores or MinMax scaling
def scaleFeatures(trainx_df,testx_df,scale='Standard'):
    if scale == 'Standard':
        scaler = preprocessing.StandardScaler().fit(trainx_df)
        trainx_df=scaler.transform(trainx_df)
        testx_df=scaler.transform(testx_df)
    elif scale == 'MinMax':
        scaler=preprocessing.MinMaxScaler().fit(trainx_df)
        trainx_df=scaler.transform(trainx_df)
        testx_df=scaler.transform(testx_df)
    return trainx_df,testx_df


# As a fifth step of pre-processing split the trainx_df into tow parts to build a model and test how is it working to pick best model
def splitTrainAndTest(trainx_df, trainy_df, split_ratio=0.3):
    X_train, X_test, y_train, y_test = train_test_split(trainx_df, trainy_df, test_size=split_ratio, random_state=42)
    return X_train, X_test, y_train, y_test


#model Evaluation
#get result from model   
def getScores(model, X_train, X_test, y_train, y_test): #in probalility
    y_pred = model.predict(X_test)
    print(classification_report(y_pred, y_test))


#get svc scores
def getSVCScores(model, X_train, X_test, y_train, y_test):
    yhat = model.predict(X_test)
    
    print(classification_report(yhat, y_test))
    '''print(classification_report(y_test, yhat, output_dict=True)['1']['precision'],
     classification_report(y_test, yhat, output_dict = True)['1']['recall'])'''
    

# Prediction on unseen data
def predictTestx(Model, testx_df):
    prediction = Model.predict(testx_df)
    testpred=pd.DataFrame(prediction)
    #print("accuracy score: ", accuracy_score(prediction, y_test))
    #print('confusion Matrix: ', confusion_matrix(prediction, y_test))
    testpred.to_csv("test_pred.csv")


trainx_df,trainy_df,testx_df=readDataSets("train.csv","test.csv", predict_col='Survived', index_col='PassengerId')
trainx_df,testx_df=dropFeaturesWithNullValues(trainx_df, testx_df,null_ratio=0.5)
trainx_df,testx_df = convertCategoricalFeatures(trainx_df,testx_df)
#print(trainx_df.shape)

trainx_df,testx_df=fillMissingValues(trainx_df,testx_df)

trainx_df,testx_df=scaleFeatures(trainx_df,testx_df,scale='Standard')
#print(trainx_df)
X_train, X_test, y_train, y_test=splitTrainAndTest(trainx_df, trainy_df,split_ratio=0.3)
print("Logistic Regression result") #build model
LogRegModel = LogisticRegression(C=0.01, max_iter=10000, class_weight='balanced').fit(X_train, y_train)
getScores(LogRegModel, X_train, X_test, y_train, y_test) 

print('results for SVM classifier')
SVCModel = SVC(C = 0.0001, degree = 2, kernel='linear').fit(X_train, y_train) #deg of kernel
getSVCScores(SVCModel, X_train, X_test, y_train, y_test)

KNN_model = KNeighborsClassifier(n_neighbors=2).fit(X_train, y_train)

predictTestx(KNN_model, testx_df)


