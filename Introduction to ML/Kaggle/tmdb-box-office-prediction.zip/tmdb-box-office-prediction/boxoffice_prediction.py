#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct  1 10:44:33 2020

@author: tsheringlhamo
"""


import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.impute import KNNImputer
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error as mserr
import warnings
warnings.filterwarnings(action="ignore")

#load dataset
def readDataSets(train_path, test_path,predict_col,index_col=None):
    if index_col==None:
        trainx_df=pd.read_csv(train_path)
        trainy_df=trainx_df[predict_col]
     
        trainx_df.drop(predict_col,axis=1,inplace=True) # axis 1 means colwise, inplace true create new df
        testx_df=pd.read_csv(test_path)
    else:
        trainx_df=pd.read_csv(train_path,index_col=index_col)
        #print(trainx_df.shape)
        trainy_df=trainx_df[predict_col] #target prediction column revenue
        #print(trainx_df.corr())
        trainx_df.drop(predict_col,axis=1,inplace=True)
        testx_df=pd.read_csv(test_path,index_col=index_col)
        #print(testx_df.shape)
    return trainx_df,trainy_df,testx_df
  
#data preprocessing
def dropFeaturesWithNullValues(trainx_df, testx_df,null_ratio=0.3):
    sample_size = len(trainx_df)
    columns_with_null_values = [[col,float(trainx_df[col].isnull().sum())/float(sample_size)] 
                              for col in trainx_df.columns if trainx_df[col].isnull().sum()]
    columns_to_drop = [x for (x,y) in columns_with_null_values if y>null_ratio]
    #print(columns_to_drop)
    trainx_df.drop(columns_to_drop,axis=1,inplace=True)
    testx_df.drop(columns_to_drop,axis=1,inplace=True)
    return trainx_df,testx_df

def convertCategoricalFeatures(trainx_df, testx_df):
    categorical_columns = [col for col in trainx_df.columns 
                         if trainx_df[col].dtype==object]
    #print(trainx_df[col].value_counts())
    trainx_df.drop(categorical_columns,axis=1,inplace=True)
    testx_df.drop(categorical_columns,axis=1,inplace=True)
    #print(trainx_df.shape)
    
    return trainx_df, testx_df

def fillMissingValues(trainx_df,testx_df):
    imputer = KNNImputer(n_neighbors=2)
    imputer.fit(trainx_df)
    trainx_df_filled = imputer.transform(trainx_df)
    trainx_df_filled = pd.DataFrame(trainx_df_filled,columns=trainx_df.columns)
    testx_df_filled = imputer.transform(testx_df)
    testx_df_filled = pd.DataFrame(testx_df_filled,columns=testx_df.columns)
    testx_df_filled.reset_index(drop=True,inplace=True)
    return trainx_df_filled,testx_df_filled


def scaleFeatures(trainx_df,testx_df, scale='Standard'):
    if scale == 'Standard':
        scaler = preprocessing.StandardScaler().fit(trainx_df)
        trainx_df = scaler.transform(trainx_df)
        testx_df = scaler.transform(testx_df)
    elif scale == 'MinMax':
        scaler = preprocessing.MinMaxScaler().fit(trainx_df)
        trainx_df = scaler.transform(trainx_df)
        testx_df = scaler.transform(testx_df)
    return trainx_df,testx_df


def splitTrainAndTest(trainx_df, trainy_df, split_ratio=0.3):
    X_train, X_test, y_train, y_test = train_test_split(trainx_df, trainy_df, test_size=split_ratio, random_state=42)
    return X_train, X_test, y_train, y_test

    
# Tune regularization Parameter based on R^2 value or mse
def getRSqureandMSEVsAlphaPlots(X_train, X_test, y_train, y_test,alpha_start=.75,alpha_end=1.25, jumps=10):
    score_train=[] 
    score_test=[]
    mse_train=[]
    mse_test=[]
    alpha=[]
    for sigma in np.linspace(alpha_start, alpha_end, jumps): #numpy array
        alpha.append(sigma)
        reg = Ridge(alpha=sigma,tol=0.001)
        Ridge_model= reg.fit(X_train, y_train)
        score_train.append(round(Ridge_model.score(X_train, y_train),10))
        score_test.append(round(Ridge_model.score(X_test, y_test),10))
        mse_train.append(round(mserr(y_train,Ridge_model.predict(X_train)),4))
        mse_test.append(round(mserr(y_test,Ridge_model.predict(X_test)),4))

    #print(alpha,'\n', score_train, '\n',score_test,'\n', mse_train, '\n',mse_test) 
    plt.figure(1)
    plt.plot(alpha, score_train, 'g--',label="train_score")
    plt.plot(alpha, score_test, 'r-o',label="test_score")
    plt.xlabel='Alpha'
    plt.ylabel='r square'
    plt.legend()
    plt.figure(2)
    plt.plot(alpha, mse_train, 'y--',label="train_mse")
    plt.plot(alpha, mse_test, 'c-o',label="test_mse")
    plt.xlabel='Alpha'
    plt.ylabel='Mean squared error'
    plt.legend()
    plt.show()

    
# Predict revenue on unseen data
def predictTestx(Model, testx_df):
    prediction = Model.predict(testx_df)
    test_pred = pd.DataFrame(prediction)
    test_pred.to_csv("submission.csv")

trainx_df,trainy_df,testx_df = readDataSets("train.csv","test.csv", predict_col='revenue',index_col="id")

if trainx_df.isnull().sum().any() and testx_df.isnull().sum().any():
    trainx_df,testx_df = dropFeaturesWithNullValues(trainx_df, testx_df,null_ratio=0.3)
  
trainx_df,testx_df = convertCategoricalFeatures(trainx_df,testx_df)
#print(trainx_df.isna().sum())
if trainx_df.isna().sum().any() and testx_df.isna().sum().any():
    trainx_df,testx_df = fillMissingValues(trainx_df,testx_df)

#print(trainx_df.corr())
trainx_df,testx_df=scaleFeatures(trainx_df,testx_df,scale='Standard')
X_train, X_test, y_train, y_test = splitTrainAndTest(trainx_df, trainy_df, split_ratio=0.3)

#build models
LRModel = LinearRegression().fit(X_train, y_train)
print("Linear train r2: ",LRModel.score(X_train, y_train)) # r2value
print('Linear test r2: ', LRModel.score(X_test, y_test)) 
#print(X_train.shape)

RidgeModel = Ridge(alpha=.01,tol=1.0, max_iter = 10000).fit(X_train, y_train)
print("Ridge train r2: ",RidgeModel.score(X_train, y_train)) 
print('Ridge test r2: ', RidgeModel.score(X_test, y_test))

LassoModel = Lasso(alpha = .001, max_iter = 10000).fit(X_train, y_train)
print('Lasso train r2: ', LassoModel.score(X_train, y_train))

getRSqureandMSEVsAlphaPlots(X_train, X_test, y_train, y_test,alpha_start=.001,alpha_end=.01,jumps=10)
rf = RandomForestRegressor(n_estimators = 100, random_state = 42).fit(X_train, y_train) #number of trees 100

predictTestx(LassoModel, testx_df)
